#ifndef _IIMPLDYNAMIC_PROPERTY_H
#define _IIMPLDYNAMIC_PROPERTY_H

#include <mutex>
#include "IDynamicProperty.h"
#include "ImplDependencyWatcher.h"

namespace CppTest
{
    template<typename T> class ImplDynamicProperty : public IDynamicProperty<T>
    {
        public:
            ImplDynamicProperty(const T & value)
                : _value(value)
            {}

            ImplDynamicProperty() {}

            /*
             * Gets the value of the property
             */
            virtual T getValue() const;

            /*
             * Sets the value of the property and notifies all subscribers of the new value
             */
            virtual void setValue(T value);

        private:
            T _value;

            typedef std::recursive_mutex mutex;
            mutable mutex _mutex;
    };

    template<typename T> T ImplDynamicProperty<T>::getValue() const
    {
        std::lock_guard<mutex> lock(_mutex);
        ImplDependencyWatcher::capture(this);
        return _value;
    };

    template<typename T> void ImplDynamicProperty<T>::setValue(T value)
    {
        std::lock_guard<mutex> lock(_mutex);
        _value = value;
        this->notifySubscribers(value);
    }
}



#endif
