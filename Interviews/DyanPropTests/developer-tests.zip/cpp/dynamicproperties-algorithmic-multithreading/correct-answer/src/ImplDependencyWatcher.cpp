#include "ImplDependencyWatcher.h"
#include <stack>

namespace CppTest
{
    __thread std::stack<ImplDependencyWatcher *> * ImplDependencyWatcher::_evaluationContexts = nullptr;

    ImplDependencyWatcher::~ImplDependencyWatcher()
    {
        for (auto & c : _connections)
        {
            c.disconnect();
        }
    }

    void ImplDependencyWatcher::advanceStateOrSignal(unsigned char targetState, unsigned char signalState)
    {
        // If we are in the DEFAULT state, then change to targetState.
        // If we fail because we are in signalState, then send the signal (and change to COMPLETE state)
        unsigned char state = State::DEFAULT;
        if (!_state.compare_exchange_strong(state, targetState) && (state == signalState))
        {
            // Try to transition to COMPLETE
            // If we succeed, then send the signal
            // If we fail, then another thread beat us to the punch
            if (_state.compare_exchange_strong(state, State::COMPLETE))
            {
                _callback();
            }
        }
    }

    void ImplDependencyWatcher::callback()
    {
        advanceStateOrSignal(State::SIGNALED, State::READY);
    }

    void ImplDependencyWatcher::ready()
    {
        advanceStateOrSignal(State::READY, State::SIGNALED);
    }
}

