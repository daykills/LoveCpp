#ifndef _IMPL_COMPUTED_PROPERTY_H
#define _IMPL_COMPUTED_PROPERTY_H

#include "IDynamicProperty.h"
#include "ImplDependencyWatcher.h"

namespace CppTest
{
    template<typename T> class ImplComputedProperty : public IDynamicProperty<T>
    {
        public:
            ImplComputedProperty(std::function<T()> const & read, std::function<void(T)> const & write)
                : _read(read), _write(write)
            {
                _value = evaluate();
                _watcher->ready();
            }

            virtual T getValue() const;
            virtual void setValue(T value);

        private:

            T evaluate();
            void reevaluate();

            T _value;
            std::function<T()> _read;
            std::function<void(T)> _write;
            std::unique_ptr<ImplDependencyWatcher> _watcher;
    };

    template<typename T> T ImplComputedProperty<T>::getValue() const
    {
        ImplDependencyWatcher::capture(this);
        return _value;
    }

    template<typename T> void ImplComputedProperty<T>::setValue(T value)
    {
        _write(value);
    }

    template<typename T> T ImplComputedProperty<T>::evaluate()
    {
        std::function<void()> callback = [this]() { reevaluate(); };
        _watcher.reset(ImplDependencyWatcher::newEvaluationContext(callback));

        // Not the prettiest.  I should use RAII instead
        try
        {
            auto r = _read();
            ImplDependencyWatcher::endContext();
            return r;
        }
        catch(...)
        {
            ImplDependencyWatcher::endContext();
            throw;
        }
    }

    template<typename T> void ImplComputedProperty<T>::reevaluate()
    {
        _value = evaluate();
        this->notifySubscribers(_value);
        _watcher->ready(); // start responding to dependency change signals
    }
}



#endif
