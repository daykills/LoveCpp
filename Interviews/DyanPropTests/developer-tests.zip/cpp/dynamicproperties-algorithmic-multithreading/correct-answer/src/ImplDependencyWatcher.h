#ifndef _IMPL_DEPENDENCY_WATCHER_H
#define _IMPL_DEPENDENCY_WATCHER_H

#include "IDynamicProperty.h"
#include <atomic>
#include <list>
#include <stack>

namespace CppTest
{

    /*
     * Used by the ComputedProperty to monitor dependencies for change.
     * It will start listening immediately but will defer notification until ready() is called.
     */
    class ImplDependencyWatcher
    {
        public:
            ~ImplDependencyWatcher();

            /*
             * Call when you are ready to receive the dependency changed signal.
             * If the signal has already been received and deferred, you will receive it immediately
             */
            void ready();

            /*
             * Start monitoring this property for changes
             */
            template<typename T> void addDependency(IDynamicProperty<T> const * observable);

            /*
             * Capture this observable as a dependency of the current dependency context
             */
            template<typename T> static void capture(IDynamicProperty<T> const * observable);
            static ImplDependencyWatcher * newEvaluationContext(std::function<void()> const & callback)
            {
                if (!_evaluationContexts)
                {
                    _evaluationContexts = new std::stack<CppTest::ImplDependencyWatcher *>();
                }

                auto w = new ImplDependencyWatcher(callback);
                _evaluationContexts->push(w);
                return w;
            }

            static void endContext() { _evaluationContexts->pop(); }

        private:
            ImplDependencyWatcher(std::function<void()> const & callback)
                : _state(State::DEFAULT), _callback(callback)
            {}

            /*
             * Callback subscribed to dependencies.
             */
            void callback();

            void advanceStateOrSignal(unsigned char targetState, unsigned char signalState);

            enum State : unsigned char { DEFAULT, SIGNALED, READY, COMPLETE };
            std::atomic_uchar _state;
            std::function<void()> _callback;
            std::list<boost::signals2::connection> _connections;
            std::list<void const *> _dependencies;

            /*
             * gcc bug http://gcc.gnu.org/bugzilla/show_bug.cgi?id=55800
             * prevents us from using C++11 thread_local modifier
             */
            static __thread std::stack<CppTest::ImplDependencyWatcher *> * _evaluationContexts;
    };

    template<typename T> void ImplDependencyWatcher::addDependency(IDynamicProperty<T> const *observable)
    {
        // see if we already have this dependency
        // note: linear search inefficient if we have alot of dependencies.  use an unordered_set instead?
        auto it = std::find(_dependencies.begin(), _dependencies.end(), observable);
        if (it == _dependencies.end())
        {
            _dependencies.push_front(observable);
            // Create a lambda that takes a single T argument.  Ignore the value and call this->callback();
            // use this lambda to subscribe to the observable
            auto c = observable->subscribe([this] (T) { callback(); });
            _connections.push_front(c);
        }
    }

    template<typename T> void ImplDependencyWatcher::capture(IDynamicProperty<T> const * observable)
    {
        if (_evaluationContexts && !_evaluationContexts->empty())
        {
            _evaluationContexts->top()->addDependency(observable);
        }
    }
}



#endif
