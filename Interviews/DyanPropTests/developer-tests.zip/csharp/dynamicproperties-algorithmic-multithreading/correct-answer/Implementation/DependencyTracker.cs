﻿namespace Developer.Test
{
    using System;
    using System.Collections.Generic;
    using System.Reactive;
    using System.Reactive.Linq;
    using System.Reactive.Subjects;
    using System.Runtime.CompilerServices;
    using System.Threading;

    /// <summary>
    /// Used to track dependencies for computed properties.
    /// </summary>
    internal static class DependencyTracker
    {
        /// <summary>
        /// compares using reference equality, even if the objects implement IEquatable
        /// </summary>
        private class ReferenceEqualityComparer : IEqualityComparer<object>
        {
            public new bool Equals(object x, object y)
            {
                return ReferenceEquals(x, y);
            }

            public int GetHashCode(object obj)
            {
                return RuntimeHelpers.GetHashCode(obj);
            }

            public static readonly ReferenceEqualityComparer Instance = new ReferenceEqualityComparer();
        }

        private class EvaluationContext : IDisposable
        {
            private readonly Subject<IObservable<Unit>> _signals;
            private readonly HashSet<object> _dependencies;

            public EvaluationContext()
            {
                _signals = new Subject<IObservable<Unit>>();
                _dependencies = new HashSet<object>(ReferenceEqualityComparer.Instance);
                s_contexts.Value.Push(this);
            }

            public void Capture<T>(IDynamicProperty<T> property)
            {
                if (_dependencies.Add(property))
                {
                    var v = Observable.Create<Unit>(observer => property.Subscribe(x => observer.OnNext(Unit.Default)));
                    _signals.OnNext(v);
                }
            }

            public IObservable<Unit> Signal
            {
                get
                {
                    return _signals.Merge().Take(1);
                }
            }

            public void Dispose()
            {
                s_contexts.Value.Pop();
                _signals.OnCompleted();
                _signals.Dispose();
            }
        }

        /// <summary>
        /// We capture all of the evaluations that occur on the current thread so we need a separate context frame for each thread.
        /// </summary>
        private static readonly ThreadLocal<Stack<EvaluationContext>> s_contexts = new ThreadLocal<Stack<EvaluationContext>>(() => new Stack<EvaluationContext>(), false);

        /// <summary>
        /// Starts a new evaluation context.  Call dispose when you are done with the context.
        /// </summary>
        /// <returns></returns>
        public static IDisposable NewEvaluationContext(out IObservable<Unit> dependencyUpdatedSignal)
        {
            var context = new EvaluationContext();
            dependencyUpdatedSignal = context.Signal;
            return context;
        }

        public static void CaptureDependency<T>(IDynamicProperty<T> property)
        {
            if (s_contexts.IsValueCreated && s_contexts.Value.Count > 0)
            {
                s_contexts.Value.Peek().Capture(property);
            }
        }
    }
}
