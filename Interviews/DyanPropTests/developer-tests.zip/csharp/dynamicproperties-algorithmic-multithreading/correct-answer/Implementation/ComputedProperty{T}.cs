﻿namespace Developer.Test
{
    using System;
    using System.Reactive;
    using System.Reactive.Disposables;
    using System.Reactive.Linq;
    using System.Reactive.Subjects;

    /// <summary>
    /// An observable property that is computed on the fly
    /// </summary>
    public class ComputedProperty<T> : Disposable, IDynamicProperty<T>
    {
        private readonly DynamicProperty<T> _value;
        private readonly Func<T> _read;
        private readonly Action<T> _write;
        private IObservable<Unit> _dependencyChangedSignals;
        private readonly SerialDisposable _signalAsyncSubscription;
        private readonly IDisposable _evaluateSubscription;

        /// <inheritdoc />
        protected override void DisposeManagedResources()
        {
            _evaluateSubscription.Dispose();
            _signalAsyncSubscription.Dispose();
        }

        /// <summary>
        /// Constructs a new computed.
        /// </summary>
        /// <param name="read">Called to calculate the value of the observable.  If this method accesses any observables, then those dependencies will be automatically captured.</param>
        /// <param name="write">Called when a new value is written.</param>
        public ComputedProperty(Func<T> read, Action<T> write)
        {
            if (read == null)
            {
                throw new ArgumentNullException("read");
            }

            if (write == null)
            {
                throw new ArgumentNullException("write");
            }

            _read = read;
            _write = write;
            _value = new DynamicProperty<T>(default(T));
            _signalAsyncSubscription = new SerialDisposable();

            /* Everytime we evaluate, we will assign a new observable to _dependencyChangedSignals
             * this observable will complete immediately if there are no dependencies to watch
             * otherwise this observable will produce a single value when one of the dependencies
             * change, indicating we should re-evaluate (and assign a new observable to _dependencyChangedSignals)
             * If there are no dependencies and thus the signal completes without a value,
             * we will end up with _dependencyChangedSignals == null, which will cause
             * the sequence to be torn down, since having no dependencies means we never need to re-evaluate.
             * 
             * First, assign a value that will complete immediately.  This is to trigger the initial evaluation
             */
            _dependencyChangedSignals = Observable.Return(Unit.Default);
            _evaluateSubscription = Observable.Defer(() =>
                {
                    var result = _dependencyChangedSignals;
                    _dependencyChangedSignals = null;
                    return result;
                })
                .RepeatWhile(() => _dependencyChangedSignals != null)
                .Select(signal => Evaluate())
                .Subscribe(v => _value.Value = v);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope", Justification = "We do not really need to dispose of Subjects.")]
        private void NewDependencyChangedSignal(IObservable<Unit> signal)
        {
            // We need to immediately subscribe to the signal to capture any signals that might arrive while we are evaluating.
            // If we just give it to our subject, then our _evaluateSubscription construct might not immediately subscribe because it might
            // be busy processing an OnNext call.  So we will create an AsyncSubject and subscribe it to the signal.  It is the
            // AsyncSubject we will put in our _evaluateSubscription construct
            var s = new AsyncSubject<Unit>();
            _signalAsyncSubscription.Disposable = signal.Subscribe(s);
            _dependencyChangedSignals = s;
        }

        private T Evaluate()
        {
            IObservable<Unit> dependencyChangedSignal;
            using (DependencyTracker.NewEvaluationContext(out dependencyChangedSignal))
            {
                NewDependencyChangedSignal(dependencyChangedSignal);
                return _read();
            }
        }

        /// <inheritdoc />
        public IDisposable Subscribe(Action<T> observer)
        {
            return _value.Subscribe(observer);
        }

        /// <inheritdoc />
        public T Value
        {
            get { return _value.Value; }
            set { _write(value); }
        }
    }
}
