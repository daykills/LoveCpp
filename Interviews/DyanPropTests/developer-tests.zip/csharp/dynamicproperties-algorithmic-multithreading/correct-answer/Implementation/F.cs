﻿namespace Developer.Test
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Usefule RX extensions for observables
    /// </summary>
    public static class F
    {
        /// <summary>
        /// Returns an enumerable that repeats a value as long as <paramref name="predicate"/> returns true.
        /// </summary>
        /// <typeparam name="T">The data type being enumerated</typeparam>
        /// <param name="value">The value to repeat.</param>
        /// <param name="predicate">Method which should return false when the sequence should end.</param>
        /// <returns>A sequence which repeats the same value as long as a condition is met.</returns>
        /// <remarks>Mostly useful in multi-threaded scenarios</remarks>
        public static IEnumerable<T> RepeatWhile<T>(T value, Func<bool> predicate)
        {
            // Code Contracts do not really work on an iterator function, so we move the iterator function to a private helper.
            return RepeatWhilePrivate(value, predicate);
        }

        private static IEnumerable<T> RepeatWhilePrivate<T>(T value, Func<bool> predicate)
        {
            while (predicate())
            {
                yield return value;
            }

            yield break;
        }

        /// <summary>
        /// Returns an enumerable that repeats a value as long as <paramref name="predicate"/> returns true.
        /// </summary>
        /// <typeparam name="T">The data type being enumerated</typeparam>
        /// <param name="value">The value to repeat.</param>
        /// <param name="predicate">
        /// Method which should return false when the sequence should end.
        /// Each time it is called, it receives the number of times <paramref name="value"/> has been repeated.  So it will receive 0 the first time, 1 the next, etc.
        /// </param>
        /// <returns>A sequence which repeats the same value as long as a condition is met.</returns>
        /// <remarks>Mostly useful in multi-threaded scenarios</remarks>
        public static IEnumerable<T> RepeatWhile<T>(T value, Func<int, bool> predicate)
        {
            // Code Contracts do not really work on an iterator function, so we move the iterator function to a private helper.
            return RepeatWhilePrivate(value, predicate);
        }

        private static IEnumerable<T> RepeatWhilePrivate<T>(T value, Func<int, bool> predicate)
        {
            var index = 0;
            while (predicate(index++))
            {
                yield return value;
            }
        }
    }
}
