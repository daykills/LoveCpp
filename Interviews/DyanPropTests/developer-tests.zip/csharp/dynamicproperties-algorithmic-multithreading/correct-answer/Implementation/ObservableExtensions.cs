﻿namespace Developer.Test
{
    using System;
    using System.Reactive.Linq;

    /// <summary>
    /// Usefule RX extensions for observables
    /// </summary>
    public static class ObservableExtensions
    {
        /// <summary>
        /// Repeatedly subscribes to <paramref name="source"/> while <paramref name="predicate"/> returns true.
        /// Each time the <paramref name="source"/> completes, if a call to <paramref name="predicate"/> returns true, then <paramref name="source"/> will be resubscribed.
        /// </summary>
        /// <typeparam name="TSource">The data-type of the observable</typeparam>
        /// <param name="source">The source observable to repeatedly resubscribe to</param>
        /// <param name="predicate">Checked before each subscription to <paramref name="source"/>.  Should return false to stop the observable.</param>
        /// <returns>An observable which will repeat the same observable over and over.</returns>
        public static IObservable<TSource> RepeatWhile<TSource>(this IObservable<TSource> source, Func<bool> predicate)
        {
            return F.RepeatWhile(source, predicate).Concat();
        }

        /// <summary>
        /// Repeatedly subscribes to <paramref name="source"/> while <paramref name="predicate"/> returns true.
        /// Each time the <paramref name="source"/> completes, if a call to <paramref name="predicate"/> returns true, then <paramref name="source"/> will be resubscribed.
        /// <paramref name="source"/> is resubscribed.
        /// </summary>
        /// <typeparam name="TSource">The data-type of the observable</typeparam>
        /// <param name="source">The source observable to repeatedly resubscribe to</param>
        /// <param name="predicate">
        /// Checked before each subscription to <paramref name="source"/>.
        /// Should return false to stop the observable.
        /// Will be passed an integer argument of the number of times <paramref name="source"/> has been subscribed so far.
        /// So, will be called with 0, 1, 2, 3 ...
        /// </param>
        /// <returns>An observable which will repeat the same observable over and over.</returns>
        public static IObservable<TSource> RepeatWhile<TSource>(this IObservable<TSource> source, Func<int, bool> predicate)
        {
            return F.RepeatWhile(source, predicate).Concat();
        }
    }
}
