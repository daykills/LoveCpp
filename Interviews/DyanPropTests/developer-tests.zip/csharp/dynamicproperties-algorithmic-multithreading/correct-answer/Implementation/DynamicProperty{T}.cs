﻿namespace Developer.Test
{
    using System;
    using System.Reactive.Linq;
    using System.Reactive.Subjects;

    /// <summary>
    /// Represents a property that can be observed or updated.  Notifications are sent out if the value is actually changed to a different value.
    /// </summary>
    public class DynamicProperty<T> : IDynamicProperty<T>
    {
        private readonly BehaviorSubject<T> _subject;

        /// <summary>
        /// Initializes the property
        /// </summary>
        /// <param name="initialValue">The initial value</param>
        public DynamicProperty(T initialValue)
        {
            _subject = new BehaviorSubject<T>(initialValue);
        }

        /// <inheritdoc />
        public T Value
        {
            get
            {
                DependencyTracker.CaptureDependency(this);

                return _subject.Value;
            }
            set
            {
                _subject.OnNext(value); 
            }
        }

        /// <inheritdoc />
        public IDisposable Subscribe(Action<T> observer)
        {
            return _subject.Skip(1).Subscribe(observer);
        }
    }
}
